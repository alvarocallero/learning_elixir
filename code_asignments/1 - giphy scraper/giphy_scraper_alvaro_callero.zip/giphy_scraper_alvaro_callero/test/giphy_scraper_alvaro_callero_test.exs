defmodule GiphyScraperAlvaroCalleroTest do
  use ExUnit.Case
  doctest GiphyScraperAlvaroCallero

  test "greets the world" do
    assert GiphyScraperAlvaroCallero.hello() == :world
  end
end
